module.exports = {
  BOT_TOKEN: "7556467882:AAH_omXL0JIY7-VngNILBNuAptnHI7emyNQ",
};